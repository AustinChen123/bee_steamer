import cv2
import asyncio
import datetime
import json
import os
import numpy as np
from app.websocket_server import connected_clients

ALL_HIVES = {
    "Hive_1": (270, 278, 562, 501),
    "Hive_2": (219, 338, 494, 571),
    "Hive_3": (516, 263, 841, 496),
}

BEE_AREA_MIN = 20
BEE_AREA_MAX = 300
BACKGROUND_FRAMES = 15
ANALYSIS_INTERVAL = 300  # 每 5 分鐘

BG_HIVE1_STATIC = cv2.imread("background_hive1.png", cv2.IMREAD_GRAYSCALE)
BG_HIVE23_STATIC = cv2.imread("background_hive23.png", cv2.IMREAD_GRAYSCALE)

def count_bees(fg_mask, roi):
    x1, y1, x2, y2 = roi
    roi_mask = fg_mask[y1:y2, x1:x2]
    contours, _ = cv2.findContours(roi_mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    return sum(1 for c in contours if BEE_AREA_MIN < cv2.contourArea(c) < BEE_AREA_MAX)

async def build_background(cap, num_frames):
    frames = []
    for _ in range(num_frames):
        ret, frame = cap.read()
        if not ret:
            continue
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        frames.append(gray)
        await asyncio.sleep(0.1)
    if not frames:
        return None
    return np.mean(frames, axis=0).astype(np.uint8)

async def analyze_every_interval(cap, hive_names, static_bg):
    while True:
        bg = await build_background(cap, BACKGROUND_FRAMES)
        if bg is None:
            bg = static_bg

        ret, frame = cap.read()
        if not ret:
            await asyncio.sleep(ANALYSIS_INTERVAL)
            continue

        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        diff = cv2.absdiff(gray, bg)
        _, fg_mask = cv2.threshold(diff, 30, 255, cv2.THRESH_BINARY)

        result = {}
        for name in hive_names:
            roi = ALL_HIVES[name]
            result[name] = count_bees(fg_mask, roi)
        result["timestamp"] = datetime.datetime.utcnow().isoformat()
        msg = json.dumps(result)
        await asyncio.gather(*[ws.send(msg) for ws in connected_clients])

        await asyncio.sleep(ANALYSIS_INTERVAL)
